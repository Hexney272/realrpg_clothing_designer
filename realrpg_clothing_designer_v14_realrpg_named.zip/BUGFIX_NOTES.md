# Bugfix notes (V14 review)

A teljes V14 szkript átnézése után a következő hibákat találtam és javítottam:

## Kritikus
1. **`fx_version '14.0.0'` (fxmanifest.lua és az addon-export sablon a server/main.lua-ban)**
   – az `fx_version` mezője a FiveM-ben egy kódnév (`'cerulean'`), nem verziószám. Egy
   érvénytelen `fx_version` érték miatt a resource (és minden exportált addon resource)
   egyáltalán nem indul el. Javítva `'cerulean'`-ra mindkét helyen.
2. **Két teljesen különálló, egymást nem ismerő authorization tároló** – a régi
   `grantedAccess` (amit az `openDesigner()` / `checkAccess` RPC használt) és az új
   `rcdAuthorizedPlayers` (amit a V14 `client:openClothingDesigner` / `rpcHasAccess` flow
   használt) két külön Lua táblában tartották számon, kik jogosultak. Ha valakinek az egyik
   API-n (pl. `exports:grantPlayerAccess`) keresztül adtál jogot, a másik rendszer
   (`rpcHasAccess`) ezt nem látta, és fordítva. Ez azt jelentette, hogy a dokumentált
   "grant then open" flow (lásd REALRPG_EXPORTS_RPC_V14.md) megbízhatatlanul működött.
   Javítva: egy közös `sharedAccess` táblára lettek húzva mindkét réteg.
3. **`readAllFiles()` (server/main.lua) `io.popen` shell parancsokkal** – ugyanaz a hiba,
   mint a V11-ben: a FXServer sandbox csak az emulált `ls`/`dir`-t engedi, `find` mindig
   "Permission denied"-et adott, így a template auto-scan soha nem talált fájlt. Javítva
   `io.readdir()`-re.

## Közepes
4. **Duplikált `grantPlayerAccess` / `revokePlayerAccess` / `hasPlayerAccess` exportok** –
   mindhárom kétszer volt regisztrálva (egyszer a régi, egyszer az új RPC réteg mellett), a
   második regisztráció csendben felülírta az elsőt. A duplikátum eltávolítva.
5. **Duplikált `ESX.RegisterServerCallback('realrpg_clothing_designer:getSkin:server', ...)`**
   – szó szerint kétszer regisztrálva. A redundáns törölve.
6. **`Config.AllowedModels` nem volt érvényesítve** a `setModel` NUI callbackben – bárki
   bármilyen model hash-re állíthatta a karaktert. Javítva `isModelAllowed()` ellenőrzéssel.
7. **`Config.TeleportWhenCreatingChar`, `Config.SetCoordsAfterFinalize`,
   `Config.CharacterFinalized`** deklarálva voltak, de sosem lettek felhasználva. Bekötve az
   `openDesigner()` / `closeDesigner()` flow-ba, plusz egy új
   `realrpg_clothing_designer:characterFinalized` net event hívja a szerver oldali hookot.
8. **`originalCoords` dead variable (client)** – most visszaállítja a játékos pozícióját, ha
   karakterkészítés közben megszakítják a designer-t.

## Apró
9. `parseTemplatePath`-ban egy no-op `:gsub('/','/')` eltávolítva.

Módosított fájlok: `fxmanifest.lua`, `server/main.lua`, `client/main.lua`.
