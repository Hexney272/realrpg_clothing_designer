# RealRPG Clothing Designer V11 Docs-Parity

V11 cél: a 0r-clothing_designer által leírt template folder rules / preview generation / slot YTD layout / addon-first export flow RealRPG-stílusú, saját kódos implementációja.

## Fontos folder szabályok
A template-eket ide kell tenni:

```txt
templates/cloth_templates/
  male/
  female/
```

Támogatott component mappák:

```txt
accs
berd
decl
feet
hair
hand
head
jbib
lowr
task
teef
uppr
```

Példák:

```txt
templates/cloth_templates/male/jbib/jbib_000_u.ydd
templates/cloth_templates/female/lowr/lowr_000_r.ydd
```

## Naming rules
A V11 scan csak akkor veszi fel a template-et, ha:

- a top folder `male` vagy `female`,
- a második folder támogatott component kulcs,
- a fájl prefixe egyezik a component kulccsal,
- a kiterjesztés `.ydd` vagy `.ytd`.

Hibás példa:

```txt
templates/cloth_templates/male/jbib/hoodie_000_u.ydd
```

Ez skipelhető, mert a folder `jbib`, de a fájl prefix `hoodie`.

## Preview képek
Saját preview képeket ide lehet tenni:

```txt
templates/template_previews/<gender>/<component>/<file>.png
```

Támogatott preview kiterjesztések:

```txt
png, webp, jpg, jpeg
```

Ha nincs preview, a V11 létrehoz egy managed placeholder `.png` bejegyzést. Ezt a későbbi `screenshot-basic` folyamat felülírhatja valódi képpel.

## Slot YTD layout
Template-specifikus slot `.ytd` opciók ide kerülnek:

```txt
templates/template_slots/<template_key>/
```

Példák:

```txt
templates/template_slots/male_jbib_jbib_000/
templates/template_slots/female_accs_accs_000/
```

## Startup sync behavior
Resource startkor a V11:

- létrehozza a hiányzó workspace mappákat,
- scanneli a template foldert,
- felveszi a valid `.ydd/.ytd` template-eket SQL-be,
- hiányzó preview esetén managed preview bejegyzést hoz létre,
- slot foldert felismer,
- preview cache marker fájlt létrehoz.

## Export flow
A V11 addon-first export logikát használ:

- replace export nincs bekapcsolva,
- export JSON készül,
- addon resource folder készül az `exports/` alatt,
- mirror output is elő van készítve a `../0r-clothing_exports/` célra,
- zip output helyhez `.zip.README.txt` marker készül.

FiveM runtime alatt zip generálás nem minden hoston megbízható, ezért a ZIP-et szerveroldalon vagy gépen érdemes a kész export folderből elkészíteni.

Sikeres addon export után:

```txt
restart 0r-clothing_exports
```

## Parancsok

```txt
/clothingdesigner
/screenshotmenu
/clothingwardrobe
/clothingorders
/clothingadmin
/clothingtemplates
/rcd_check
```

## Exportok

```lua
exports['realrpg_clothing_designer']:scanTemplateFolders()
exports['realrpg_clothing_designer']:scanStreamTemplates() -- backward-compatible alias
exports['realrpg_clothing_designer']:listTemplates(category, gender)
exports['realrpg_clothing_designer']:registerTemplate(data)
exports['realrpg_clothing_designer']:exportTemplateJson(id)
exports['realrpg_clothing_designer']:exportAddon(id, addonName)
```

## Server.cfg

```cfg
ensure oxmysql
ensure ox_lib
ensure ox_target
ensure ox_inventory
ensure screenshot-basic
ensure es_extended
ensure realrpg_clothing_designer
```

Admin jog:

```cfg
add_ace group.admin realrpg.clothingdesigner.admin allow
```
