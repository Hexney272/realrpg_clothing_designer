fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'RealRPG / VeZse Development'
description 'RealRPG Clothing Designer V11 - docs-parity template folder rules, preview generation, slot YTD layout, addon-first export flow'
version '11.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    'shared/config.lua'
}

client_scripts {
    'client/main.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/main.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/app.js',
    'html/assets/*.png',
    'stream/*.ydr',
    'stream/*.ytd',
    'templates/cloth_templates/**/*.ydd',
    'templates/cloth_templates/**/*.ytd',
    'templates/template_previews/**/*.png',
    'templates/template_previews/**/*.webp',
    'templates/template_previews/**/*.jpg',
    'templates/template_previews/**/*.jpeg',
    'templates/template_slots/**/*.ytd'
}

dependencies {
    'es_extended',
    'oxmysql'
}
