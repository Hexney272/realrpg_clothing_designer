Ide kerülnek majd a valódi clothing preview stream fájlok.

V10 mapping alapból ezeket keresi:
- realrpg_preview_hoodie.ydr / .ytd
- realrpg_preview_tshirt.ydr / .ytd
- realrpg_preview_pants.ydr / .ytd
- realrpg_preview_shoes.ydr / .ytd
- realrpg_preview_cap.ydr / .ytd

Ha nincs streamelt modell, a script automatikusan ped fallback preview-t használ.
A későbbi stream-integrációban a feltöltött stream assetek alapján finomhangolható lesz a modelnév, offset, kamera fókusz és textúra mapping.
