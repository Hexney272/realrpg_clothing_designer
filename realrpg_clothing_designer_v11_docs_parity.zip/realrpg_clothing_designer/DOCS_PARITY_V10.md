# Docs parity notes V10

A V10-be a dokumentált 0R Clothing V2 és elérhető 0R Clothing Designer docs részletek alapján bekerült:

- screenshot-basic dependency előkészítés
- ESX / esx_skin elsődleges adapter
- fivem-appearance / illenium-appearance wrapper előkészítés
- character model lista férfi/női felosztással
- `/screenshotmenu`
- default cloth images vs captured images config
- gender szerinti ped model listázás
- teleport when creating char / after finalize config
- CharacterFinalized hook
- normal / restricted character creation category permits
- target és text UI interaction mód
- allowed models
- default clothing variations
- clothing pricing + customs árak
- `openClothStore('clothing'|'barber'|'tattoo')`
- `wearOnOff` aliasok a dokumentált kategóriákhoz
- YDD/YTD template registry és export flow

Nem másolt elemek:
- eredeti 0R UI assetek
- eredeti escrow/source kód
- eredeti 0R imagegenerator assetek

A külön ruha mesh preview véglegesítése a tényleges stream fájlok után következik.
