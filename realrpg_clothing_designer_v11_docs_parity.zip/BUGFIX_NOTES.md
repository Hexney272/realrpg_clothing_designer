# Bugfix notes (post V11 docs-parity review)

A teljes szkript átnézése után a következő hibákat találtam és javítottam:

## Kritikus
1. **`readAllFiles()` (server/main.lua) `io.popen` shell parancsokkal** – a FXServer sandbox
   dokumentációja szerint `io.popen` csak az emulált `ls`/`dir` mintákat engedi át, minden más
   parancs (pl. `find`) "Permission denied" hibát ad vissza. Ez azt jelentette, hogy a
   `scanTemplateFolders` / `/clothingtemplates` funkció **soha nem talált semmit** – csendben
   mindig 0 fájlt adott vissza minden szerveren. Javítva: `io.readdir()` alapú rekurzív bejárásra
   cserélve, ami a dokumentált, engedélyezett API.
2. **`Config.AllowedModels` nem volt érvényesítve** – a `setModel` NUI callback bármilyen model
   hash-t elfogadott a klienstől, és rögtön `SetPlayerModel`-t hívott. Javítva: `isModelAllowed()`
   ellenőrzés hozzáadva.
3. **`Config.TeleportWhenCreatingChar`, `Config.SetCoordsAfterFinalize`, `Config.CharacterFinalized`**
   deklarálva voltak a configban, de sehol nem lettek felhasználva (dead config). Javítva:
   - `openDesigner()` most teleportál `TeleportWhenCreatingChar.Enable = true` esetén karakter-
     készítésnél.
   - `closeDesigner()` most teleportál `SetCoordsAfterFinalize.Enable = true` esetén, amikor a
     karakterkészítés befejeződik (apply = true).
   - Egy új `realrpg_clothing_designer:characterFinalized` net event hívja meg szerver oldalon a
     `Config.CharacterFinalized(source)` hookot.

## Közepes
4. **Duplikált `ESX.RegisterServerCallback('realrpg_clothing_designer:getSkin:server', ...)`** –
   szó szerint kétszer regisztrálva ugyanazzal a törzzsel. A második (redundáns) törölve.
5. **`originalCoords` dead variable (client/main.lua)** – elmentve, de sosem használva. Most a
   karakterkészítés megszakításánál (`cancel`) visszaállítja a játékos eredeti pozícióját.

## Apró
6. `parseTemplatePath`-ban egy `:gsub('/','/')` teljesen no-op volt, eltávolítva.

Módosított fájlok: `server/main.lua`, `client/main.lua`.
