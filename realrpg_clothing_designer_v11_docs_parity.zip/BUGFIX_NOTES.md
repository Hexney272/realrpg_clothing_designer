# Bugfix notes (post V11 docs-parity review)

A teljes szkript átnézése után a következő hibákat találtam és javítottam:

## Kritikus
1. **`readAllFiles()` (server/main.lua) `io.popen` shell parancsokkal** – a FXServer sandbox
   dokumentációja szerint `io.popen` csak az emulált `ls`/`dir` mintákat engedi át, minden más
   parancs (pl. `find`) "Permission denied" hibát ad vissza. Ez azt jelentette, hogy a
   `scanTemplateFolders` / `/clothingtemplates` funkció **soha nem talált semmit** – csendben
   mindig 0 fájlt adott vissza minden szerveren. Javítva: `io.readdir()` alapú rekurzív bejárásra
   cserélve, ami a dokumentált, engedélyezett API.
2. **`Config.AllowedModels` nem volt érvényesítve** – a `setModel` NUI callback bármilyen model
   hash-t elfogadott a klienstől, és rögtön `SetPlayerModel`-t hívott. Javítva: `isModelAllowed()`
   ellenőrzés hozzáadva.
3. **`Config.TeleportWhenCreatingChar`, `Config.SetCoordsAfterFinalize`, `Config.CharacterFinalized`**
   deklarálva voltak a configban, de sehol nem lettek felhasználva (dead config). Javítva:
   - `openDesigner()` most teleportál `TeleportWhenCreatingChar.Enable = true` esetén karakter-
     készítésnél.
   - `closeDesigner()` most teleportál `SetCoordsAfterFinalize.Enable = true` esetén, amikor a
     karakterkészítés befejeződik (apply = true).
   - Egy új `realrpg_clothing_designer:characterFinalized` net event hívja meg szerver oldalon a
     `Config.CharacterFinalized(source)` hookot.

## Közepes
4. **Duplikált `ESX.RegisterServerCallback('realrpg_clothing_designer:getSkin:server', ...)`** –
   szó szerint kétszer regisztrálva ugyanazzal a törzzsel. A második (redundáns) törölve.
5. **`originalCoords` dead variable (client/main.lua)** – elmentve, de sosem használva. Most a
   karakterkészítés megszakításánál (`cancel`) visszaállítja a játékos eredeti pozícióját.

## Apró
6. `parseTemplatePath`-ban egy `:gsub('/','/')` teljesen no-op volt, eltávolítva.

Módosított fájlok: `server/main.lua`, `client/main.lua`.



## 2. kör (a felhasználó által megadott jbib stream fájlok kapcsán feltárt további hibák)

7. **`fxmanifest.lua` `files{}` nem tartalmazott `stream/*.ydd` / `stream/*.ymt` mintát** –
   csak `.ydr`/`.ytd` volt engedélyezve a `stream/` mappához. Emiatt a valódi ruha
   addon-component fájlok (pl. `jbib_000_u.ydd`, `mp_m_freemode_01^jbib_000_u.ydd`) soha
   nem lettek volna leküldve a klienseknek. Javítva.
8. **`Config.ShowAllPeds`** deklarálva volt, de sehol nem lett figyelembe véve – most
   bypassolja a `Config.AllowedModels` szűrést, ha `true`-ra van állítva.
9. **`stream/README_STREAM_ASSETS.txt`** frissítve: dokumentálva a `^` (caret) prefixes
   meta-less addon streaming és a hagyományos YMT-alapú módszer közötti különbség, mivel
   ezeket NEM szabad egyszerre használni ugyanahhoz a drawable indexhez.
